import { saveDraft, getDraft } from "../utils/drafts.js";
import { ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } from "discord.js";

export const name = "announcecreate";

export async function execute(message, args) {
  const draft = getDraft(message.author.id) || {
    title: "",
    description: "",
    color: "#0099ff",
    footer: "",
    image: "",
    thumbnail: "",
    channelId: message.channel.id,
  };
  saveDraft(message.author.id, draft);

  const modal = new ModalBuilder()
    .setCustomId("announce_modal")
    .setTitle("Create Announcement")
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("title")
          .setLabel("Title")
          .setStyle(TextInputStyle.Short)
          .setValue(draft.title)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("description")
          .setLabel("Description")
          .setStyle(TextInputStyle.Paragraph)
          .setValue(draft.description)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("color")
          .setLabel("Hex Color (#000000)")
          .setStyle(TextInputStyle.Short)
          .setPlaceholder("#0099ff")
          .setValue(draft.color)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("footer")
          .setLabel("Footer Text")
          .setStyle(TextInputStyle.Short)
          .setValue(draft.footer)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("image")
          .setLabel("Image URL")
          .setStyle(TextInputStyle.Short)
          .setValue(draft.image)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("thumbnail")
          .setLabel("Thumbnail URL")
          .setStyle(TextInputStyle.Short)
          .setValue(draft.thumbnail)
      )
    );

  await message.showModal(modal);
}
