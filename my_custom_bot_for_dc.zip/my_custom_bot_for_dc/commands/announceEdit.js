import { getDraft, saveDraft } from "../utils/drafts.js";
import { ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } from "discord.js";

export const name = "announceedit";

export async function execute(message, args) {
  const draft = getDraft(message.author.id);
  if (!draft) return message.reply("No draft found. Use p!announcecreate first.");

  const modal = new ModalBuilder()
    .setCustomId("announce_modal")
    .setTitle("Edit Announcement")
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("title")
          .setLabel("Title")
          .setStyle(TextInputStyle.Short)
          .setValue(draft.title)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("description")
          .setLabel("Description")
          .setStyle(TextInputStyle.Paragraph)
          .setValue(draft.description)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("color")
          .setLabel("Hex Color (#000000)")
          .setStyle(TextInputStyle.Short)
          .setValue(draft.color)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("footer")
          .setLabel("Footer Text")
          .setStyle(TextInputStyle.Short)
          .setValue(draft.footer)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("image")
          .setLabel("Image URL")
          .setStyle(TextInputStyle.Short)
          .setValue(draft.image)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("thumbnail")
          .setLabel("Thumbnail URL")
          .setStyle(TextInputStyle.Short)
          .setValue(draft.thumbnail)
      )
    );

  await message.showModal(modal);
}
